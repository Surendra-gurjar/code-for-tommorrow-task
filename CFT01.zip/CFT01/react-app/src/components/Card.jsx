import React from "react";
import "./Card.css";

const Card = ({ post, onRemove }) => {
  return (
    <div className="post-card">
      <button className="remove-btn" onClick={() => onRemove(post.id)}>
        ×
      </button>
      <h3>{post.title}</h3>
      <p>{post.body}</p>
      <p className="post-date">Mon, 21 Dec 2020 14:57 GMT</p>
      <img
        src={`https://picsum.photos/id/${post.id}/300/200`}
        alt="post"
        className="post-image"
      />
    </div>
  );
};

export default Card;
