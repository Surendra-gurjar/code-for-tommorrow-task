import React from "react";
import "./Pagination.css";

const Pagination = ({ totalPages, currentPage, onPageChange }) => {
  const getPageNumbers = () => {
    const maxPageNumbers = 3;
    const pages = [];

    if (currentPage > maxPageNumbers) {
      for (let i = currentPage - 2; i <= currentPage; i++) {
        pages.push(i);
      }
    } else {
      for (let i = 1; i <= Math.min(maxPageNumbers, totalPages); i++) {
        pages.push(i);
      }
    }

    return pages;
  };

  const pageNumbers = getPageNumbers();

  return (
    <div className="pagination">
      {currentPage > 1 && (
        <button
          className="pagination-btn"
          onClick={() => onPageChange(currentPage - 1)}
        >
          &lt;
        </button>
      )}
      {pageNumbers.map((number) => (
        <button
          key={number}
          className={`pagination-btn ${currentPage === number ? "active" : ""}`}
          onClick={() => onPageChange(number)}
        >
          {number}
        </button>
      ))}
      {currentPage < totalPages && (
        <>
          <span className="pagination-dots">.....</span>
          <button
            className="pagination-btn"
            onClick={() => onPageChange(currentPage + 1)}
          >
            Next
          </button>
        </>
      )}
      {currentPage < totalPages && (
        <button
          className="pagination-btn"
          onClick={() => onPageChange(currentPage + 1)}
        >
          &gt;
        </button>
      )}
    </div>
  );
};

export default Pagination;
