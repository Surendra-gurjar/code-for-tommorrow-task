import React from "react";
import Card from "./Card";
import "./CardList.css";

const CardList = ({ posts, onRemove }) => {
  return (
    <div className="posts-list">
      {posts.map((post) => (
        <Card key={post.id} post={post} onRemove={onRemove} />
      ))}
    </div>
  );
};

export default CardList;
